A Pen created at CodePen.io. You can find this one at https://codepen.io/tusharshukla/pen/bRWZOm.

 random colors popping out of random background